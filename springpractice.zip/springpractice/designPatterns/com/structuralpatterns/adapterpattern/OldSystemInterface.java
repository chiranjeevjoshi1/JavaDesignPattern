package com.structuralpatterns.adapterpattern;

public class OldSystemInterface {

}

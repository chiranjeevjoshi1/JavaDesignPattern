package com.creationalpatterns.builderpattern;

public class BuilderPattern {

    /*
    A creational design pattern that lets you construct complex objects step by step.
    The pattern allows you to produce different types and representations of an object using
    the same construction code.

    Here this is the employee Class for which we will be creating builder pattern

    https://medium.com/javarevisited/builder-design-pattern-in-java-3b3bfee438d9
     */

    private String name;
    private String mobileNumber;
    private boolean hasCar; //optionalField
    private boolean hasBike; //optionalField

    private BuilderPattern(BuilderPatternBuilder builderPatternBuilder)
    {
        name = builderPatternBuilder.name;
        mobileNumber = builderPatternBuilder.mobileNumber;
        hasCar = builderPatternBuilder.hasCar;
        hasBike= builderPatternBuilder.hasBike;
    }

    public String getName()
    {
        return this.name;
    }

    public String getMobileNumber()
    {
        return this.mobileNumber;
    }

    public boolean isHasCar() {
        return hasCar;
    }

    public boolean isHasBike() {
        return hasBike;
    }

    public static class BuilderPatternBuilder{
        private String name;
        private String mobileNumber;
        private boolean hasCar; //optionalField
        private boolean hasBike; //optionalField

        public BuilderPatternBuilder(String name, String mobileNumber)
        {
            this.name = name;
            this.mobileNumber = mobileNumber;
        }

        public BuilderPatternBuilder setHasCar(boolean hasCar) {
            this.hasCar = hasCar;
            return this;
        }

        public BuilderPatternBuilder setHasBike(boolean hasBike) {
            this.hasBike = hasBike;
            return this;
        }

        public BuilderPattern build()
        {
            return new BuilderPattern(this);
        }

    }




}

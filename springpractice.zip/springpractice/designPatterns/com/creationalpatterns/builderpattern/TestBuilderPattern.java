package com.creationalpatterns.builderpattern;


class TestBuilderPattern{
    public static void main(String[] args) {
        BuilderPattern builderPattern = new BuilderPattern.BuilderPatternBuilder("Pallav","8904765917").build();
        System.out.println(builderPattern.getName());
        System.out.println(builderPattern.getMobileNumber());
        System.out.println(builderPattern.isHasBike());
        System.out.println(builderPattern.isHasCar());
    }
}

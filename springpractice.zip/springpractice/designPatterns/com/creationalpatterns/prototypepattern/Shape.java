package com.creationalpatterns.prototypepattern;

public interface Shape {
    Shape clone();
    void draw();
}

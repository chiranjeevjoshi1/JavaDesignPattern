package com.creationalpatterns.abstractfactory;

public class DroughtBeer implements Drink{
    @Override
    public void prepare() {
        System.out.println("preparing droguhtbeer");
    }

    @Override
    public void serve() {
        System.out.println("Serving droughtbeer");

    }
}

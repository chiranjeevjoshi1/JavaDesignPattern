package com.creationalpatterns.abstractfactory;

public class ItalianCuisineFactory implements AbstractFactory{
    @Override
    public NewDish createDish() {
        return new Pizza();
    }

    @Override
    public Drink createDrink() {
        return new Wine();
    }

    @Override
    public Starter createStarter() {
        return new PaneerChilli();
    }
}

package com.creationalpatterns.abstractfactory;

public class Mojito implements Drink{
    @Override
    public void prepare() {

    }

    @Override
    public void serve() {

    }
}

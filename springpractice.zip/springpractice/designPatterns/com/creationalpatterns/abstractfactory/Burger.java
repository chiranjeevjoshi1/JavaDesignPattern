package com.creationalpatterns.abstractfactory;

import com.creationalpatterns.factorypattern.Dish;

public class Burger implements NewDish {
    @Override
    public void prepare() {
        System.out.println("Sreparing burger");
    }

    @Override
    public void serve() {
        System.out.println("Serving burger");

    }
}

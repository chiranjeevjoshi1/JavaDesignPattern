package com.creationalpatterns.abstractfactory;

public interface Starter {
    void prepare();
    void serve();
}

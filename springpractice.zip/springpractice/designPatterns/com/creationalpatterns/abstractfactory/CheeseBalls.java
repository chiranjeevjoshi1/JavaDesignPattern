package com.creationalpatterns.abstractfactory;

public class CheeseBalls implements Starter{
    @Override
    public void prepare() {
        System.out.println("Preparing cheeseballs");
    }

    @Override
    public void serve() {
        System.out.println("Serving cheeseballs");
    }
}

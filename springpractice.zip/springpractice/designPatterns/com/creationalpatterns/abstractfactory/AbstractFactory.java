package com.creationalpatterns.abstractfactory;

public interface AbstractFactory {
    NewDish createDish();
    Drink createDrink();
    Starter createStarter();
}

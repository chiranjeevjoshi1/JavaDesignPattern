package com.creationalpatterns.abstractfactory;

public class Pasta implements NewDish{
    @Override
    public void prepare() {
        System.out.println("preparing pasta");
    }

    @Override
    public void serve() {
        System.out.println("serving pasta");
    }
}

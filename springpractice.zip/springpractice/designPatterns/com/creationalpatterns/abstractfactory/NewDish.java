package com.creationalpatterns.abstractfactory;

public interface NewDish {
    void prepare();
    void serve();
}

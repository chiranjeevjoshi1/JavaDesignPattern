package com.creationalpatterns.abstractfactory;

public class PaneerChilli implements Starter{
    @Override
    public void prepare() {

    }

    @Override
    public void serve() {

    }
}

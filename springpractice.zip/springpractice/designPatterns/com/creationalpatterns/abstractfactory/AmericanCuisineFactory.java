package com.creationalpatterns.abstractfactory;

public class AmericanCuisineFactory implements AbstractFactory{
    @Override
    public NewDish createDish() {
        return new Burger();
    }

    @Override
    public Drink createDrink() {
        return new DroughtBeer();
    }

    @Override
    public Starter createStarter() {
        return new CheeseBalls();
    }
}

package com.creationalpatterns.abstractfactory;

public class Wine implements Drink{
    @Override
    public void prepare() {

    }

    @Override
    public void serve() {

    }
}

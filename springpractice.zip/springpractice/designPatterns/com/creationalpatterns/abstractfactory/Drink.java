package com.creationalpatterns.abstractfactory;

public interface Drink {

    void prepare();
    void serve();
}

package com.creationalpatterns.abstractfactory;

public class Client {
    public void enjoyMeal(AbstractFactory factory)
    {
        NewDish dish = factory.createDish();
        Drink drink = factory.createDrink();
        Starter starter = factory.createStarter();
        dish.prepare();
        drink.prepare();
        starter.prepare();
        dish.serve();
        drink.serve();
        starter.serve();

    }

    public static void main(String[] args) {
        Client c = new Client();
        c.enjoyMeal(new AmericanCuisineFactory());
        c.enjoyMeal(new ItalianCuisineFactory());
    }
}

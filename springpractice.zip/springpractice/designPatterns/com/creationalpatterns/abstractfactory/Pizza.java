package com.creationalpatterns.abstractfactory;

public class Pizza implements NewDish{
    @Override
    public void prepare() {
        System.out.println("preparing pizza");
    }

    @Override
    public void serve() {
        System.out.println("serving pizza");
    }
}

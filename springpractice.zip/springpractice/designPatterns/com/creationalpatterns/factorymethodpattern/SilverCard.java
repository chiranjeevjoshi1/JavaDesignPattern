package com.creationalpatterns.factorymethodpattern;

public class SilverCard extends CardType{

    public SilverCard()
    {
        setCreditLimit();
    }
    @Override
    public void setCreditLimit() {
        cardLimit = 100000;
    }
}

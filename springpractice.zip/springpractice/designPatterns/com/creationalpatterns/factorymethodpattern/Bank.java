package com.creationalpatterns.factorymethodpattern;

import java.util.Scanner;

public class Bank {
    /*
this is a factory pattern which basically initialze the subclass at the runtime.
After the initialization at the runtime it will initiaze the variable for example
If bank provide card types: those card types could be
silver card
bronze card
platinum card
And we can set the card limit accordingly here as well.
And it will initialize card at runtime
Main gist is in the subclasses we will actually call the abstract class generic method from constructor
and then the overriden method will initialize parameter from out abstract class
https://medium.com/geekculture/overview-of-factory-method-design-pattern-d3a6fe908ea4
 */
    public static void main(String[] args) {
        Scanner sc  =new Scanner(System.in);
        System.out.println("Enter your salary");
        int salary = sc.nextInt();
        String cardType;

        if(salary<=100000)
        {
            cardType ="silver";
        }
        else if(salary<=300000)
        {
            cardType= "gold";
        }
        else
        {
            cardType = "platinum";
        }

        Factory f = new Factory();
       CardType mycard =  f.getFactory(cardType);
        System.out.println(mycard);
    }
}

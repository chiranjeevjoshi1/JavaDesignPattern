package com.creationalpatterns.factorymethodpattern;

public class PlatinumCard extends CardType{

    public PlatinumCard()
    {
        setCreditLimit();
    }
    @Override
    public void setCreditLimit() {
        cardLimit = 500000;
    }
}

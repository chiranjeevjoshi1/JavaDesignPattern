package com.creationalpatterns.factorymethodpattern;

public class Factory {

    /*
    this is a factory pattern which basically initialze the subclass at the runtime.
    After the initialization at the runtime it will initiaze the variable for example
    If bank provide card types: those card types could be
    silver card
    bronze card
    platinum card
    And we can set the card limit accordingly here as well.
    And it will initialize card at runtime
    Main gist is in the subclasses we will actually call the abstract class generic method from constructor
    and then the overriden method will initialize parameter from out abstract class
    https://medium.com/geekculture/overview-of-factory-method-design-pattern-d3a6fe908ea4
     */

    public CardType getFactory(String cardName)
    {
        if(cardName.equals("silver"))
        {
            return new SilverCard();
        }
        else if(cardName.equals("gold"))
        {
            return new GoldCard();
        }
        else
        {
            return new PlatinumCard();
        }

    }


}

package com.creationalpatterns.factorymethodpattern;

public class GoldCard extends CardType{

    public GoldCard()
    {
        setCreditLimit();
    }

    @Override
    public void setCreditLimit() {
        cardLimit = 300000;
    }
}

package com.creationalpatterns.factorymethodpattern;

public abstract class CardType {
    protected int cardLimit;
    public abstract void setCreditLimit();

    @Override
    public String toString()
    {
       return "The cardtype is "+ this.getClass().getSimpleName()+" the credit limit is"+ cardLimit;

    }
}

package com.creationalpatterns.factorypattern;

public interface Dish {
    void prepare();
    void serve();

}

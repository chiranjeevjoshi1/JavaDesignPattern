package com.creationalpatterns.factorypattern;

public class Pizza implements Dish{
    @Override
    public void prepare() {
        System.out.println("Preparing the pizza");
    }

    @Override
    public void serve() {

        System.out.println("Serving the pizza");

    }
}

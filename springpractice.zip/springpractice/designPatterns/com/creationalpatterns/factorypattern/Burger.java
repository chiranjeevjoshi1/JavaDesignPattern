package com.creationalpatterns.factorypattern;

public class Burger implements Dish{

    @Override
    public void prepare() {
        System.out.println("Preparing Burger");
    }

    @Override
    public void serve() {

        System.out.println("Serving Burger");
    }
}

package com.creationalpatterns.factorypattern;

public interface DishFactory {
    Dish createDish();
}

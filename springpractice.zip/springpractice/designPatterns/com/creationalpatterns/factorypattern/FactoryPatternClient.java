package com.creationalpatterns.factorypattern;

public class FactoryPatternClient {

    /*

    Product: This is an interface or abstract class that defines the type of objects to be created.
Concrete Product: These are the classes that implement the Product interface or extend the Product abstract class. They represent the actual objects created by the factory.
Factory: This is an interface or abstract class responsible for declaring the factory method, which creates objects of the Product type.
Concrete Factory: These are the classes that implement the Factory interface or extend the Factory abstract class. They override the factory method to produce specific instances of Product.

    The Factory Pattern is a powerful design pattern that simplifies object creation,
    enhances code organization, and promotes maintainability.
    By abstracting the creation process and delegating it to subclasses or specialized factories,
    it enables flexible, extensible, and clean code.
    Here in given code we are simplifying object creation by Creating different Dishes Using DishFactory

    We have one interface which basically implements the process and template of how to prepare dish
    And We have DishFactory Interface which will be used for Preparation of New Objects
    Now We will create classes for different factory. And we will use pizza factory dish factory to create pizza
    Here we have a ***dishfactory*** which will use to create factory object
    DishFactory will be creating the Dish Object.
    And we can have multiple kind of dish object like pizza burger sushi

    Factory Method is a creational design pattern that provides an interface for creating objects in a superclass, but allows subclasses to alter the type of objects that will be created.
    This is also known as virtual constructor.
    https://medium.com/@thecodebean/factory-design-pattern-implementation-in-java-bd16ebb012e2
    https://stackoverflow.com/questions/13029261/design-patterns-factory-vs-factory-method-vs-abstract-factory
     */
    public static void main(String[] args) {

        PizzaFactory pizzafactory = new PizzaFactory();
        Dish pizza = pizzafactory.createDish();
        pizza.prepare();
        pizza.serve();

        BurgerFactory burgerfactory = new BurgerFactory();
        Dish burger = burgerfactory.createDish();
        burger.prepare();
        burger.serve();

    }
}

package com.creationalpatterns.factorypattern;

public class BurgerFactory implements DishFactory{
    @Override
    public Dish createDish() {
        return new Burger();
    }
}

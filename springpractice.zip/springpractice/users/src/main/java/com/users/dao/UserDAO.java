package com.users.dao;

public class UserDAO {
}

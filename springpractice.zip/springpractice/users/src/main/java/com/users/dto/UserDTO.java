package com.users.dto;


import java.util.UUID;

public class UserDTO {


    private String firstName;
    private String lastName;

    private int age;


    private String mobileNumber;

    private UUID userId;

    private String userType;


    public UserDTO(String firstName, String lastName, int age, String mobileNumber, UUID userId, String userType) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.mobileNumber = mobileNumber;
        this.userId = userId;
        this.userType = userType;
    }

    public UserDTO() {
    }

    public static UserDTOBuilder builder() {
        return new UserDTOBuilder();
    }

    public boolean equals(final Object o) {
        if (o == this) return true;
        if (!(o instanceof UserDTO)) return false;
        final UserDTO other = (UserDTO) o;
        if (!other.canEqual((Object) this)) return false;
        final Object this$firstName = this.getFirstName();
        final Object other$firstName = other.getFirstName();
        if (this$firstName == null ? other$firstName != null : !this$firstName.equals(other$firstName)) return false;
        final Object this$lastName = this.getLastName();
        final Object other$lastName = other.getLastName();
        if (this$lastName == null ? other$lastName != null : !this$lastName.equals(other$lastName)) return false;
        if (this.getAge() != other.getAge()) return false;
        final Object this$mobileNumber = this.getMobileNumber();
        final Object other$mobileNumber = other.getMobileNumber();
        if (this$mobileNumber == null ? other$mobileNumber != null : !this$mobileNumber.equals(other$mobileNumber))
            return false;
        final Object this$userId = this.getUserId();
        final Object other$userId = other.getUserId();
        if (this$userId == null ? other$userId != null : !this$userId.equals(other$userId)) return false;
        final Object this$userType = this.getUserType();
        final Object other$userType = other.getUserType();
        if (this$userType == null ? other$userType != null : !this$userType.equals(other$userType)) return false;
        return true;
    }

    protected boolean canEqual(final Object other) {
        return other instanceof UserDTO;
    }

    public int hashCode() {
        final int PRIME = 59;
        int result = 1;
        final Object $firstName = this.getFirstName();
        result = result * PRIME + ($firstName == null ? 43 : $firstName.hashCode());
        final Object $lastName = this.getLastName();
        result = result * PRIME + ($lastName == null ? 43 : $lastName.hashCode());
        result = result * PRIME + this.getAge();
        final Object $mobileNumber = this.getMobileNumber();
        result = result * PRIME + ($mobileNumber == null ? 43 : $mobileNumber.hashCode());
        final Object $userId = this.getUserId();
        result = result * PRIME + ($userId == null ? 43 : $userId.hashCode());
        final Object $userType = this.getUserType();
        result = result * PRIME + ($userType == null ? 43 : $userType.hashCode());
        return result;
    }

    public String toString() {
        return "UserDTO(firstName=" + this.getFirstName() + ", lastName=" + this.getLastName() + ", age=" + this.getAge() + ", mobileNumber=" + this.getMobileNumber() + ", userId=" + this.getUserId() + ", userType=" + this.getUserType() + ")";
    }

    public String getFirstName() {
        return this.firstName;
    }

    public String getLastName() {
        return this.lastName;
    }

    public int getAge() {
        return this.age;
    }

    public String getMobileNumber() {
        return this.mobileNumber;
    }

    public UUID getUserId() {
        return this.userId;
    }

    public String getUserType() {
        return this.userType;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public void setUserType(String userType) {
        this.userType = userType;
    }

    public static class UserDTOBuilder {
        private String firstName;
        private String lastName;
        private int age;
        private String mobileNumber;
        private UUID userId;
        private String userType;

        UserDTOBuilder() {
        }

        public UserDTOBuilder firstName(String firstName) {
            this.firstName = firstName;
            return this;
        }

        public UserDTOBuilder lastName(String lastName) {
            this.lastName = lastName;
            return this;
        }

        public UserDTOBuilder age(int age) {
            this.age = age;
            return this;
        }

        public UserDTOBuilder mobileNumber(String mobileNumber) {
            this.mobileNumber = mobileNumber;
            return this;
        }

        public UserDTOBuilder userId(UUID userId) {
            this.userId = userId;
            return this;
        }

        public UserDTOBuilder userType(String userType) {
            this.userType = userType;
            return this;
        }

        public UserDTO build() {
            return new UserDTO(this.firstName, this.lastName, this.age, this.mobileNumber, this.userId, this.userType);
        }

        public String toString() {
            return "UserDTO.UserDTOBuilder(firstName=" + this.firstName + ", lastName=" + this.lastName + ", age=" + this.age + ", mobileNumber=" + this.mobileNumber + ", userId=" + this.userId + ", userType=" + this.userType + ")";
        }
    }
}

package com.users.Exceptions;

public class CustomUserException {
}

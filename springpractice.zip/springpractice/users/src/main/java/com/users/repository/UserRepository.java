package com.users.repository;

public class UserRepository {
}

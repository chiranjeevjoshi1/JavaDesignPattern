package com.users.controller;


import com.users.dao.UserDAO;
import com.users.dto.UserDTO;
import com.users.repository.UserRepository;
import com.users.service.UserService;
import lombok.NonNull;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/usersinfo")
public class UserController {

//    private final UserService userService;
//
//    public UserController(UserService userService) {
//        this.userService = userService;
//    }

    @GetMapping("/read/{id}")
    public ResponseEntity<UserDTO> readUser(@PathVariable("id") UUID id, @RequestParam("firstname") String firstname, @RequestParam("lastname") String lastname)
    {

       UUID uuid = UUID.randomUUID();
       UserDTO userDto = UserDTO.builder().age(30).lastName("Joshi").userType("Admin").mobileNumber("8904765917").firstName("Pallav").userId(id).build();
        UserDTO userDto2 = UserDTO.builder().age(30).lastName("Joshi").userType("Admin").mobileNumber("8904765917").firstName("Pallav").build();
        if(userDto.hashCode() == userDto2.hashCode())
        {
            System.out.println("this is equal");
        }
        HttpHeaders httpHeaders = new HttpHeaders();
        httpHeaders.add("hello", "yo");
       return new ResponseEntity<>(userDto, httpHeaders, HttpStatus.OK);

    }

//    @PostMapping("/")
//    public ResponseEntity<UserDTO> createUser(String data)
//    {
//        return null;
//    }
//
//    @PutMapping
//    public  ResponseEntity<UserDTO> updateUser(String data)
//    {
//        return null;
//    }
//
//    @DeleteMapping
//    public ResponseEntity<UserDTO> deleteUser(String id)
//    {
//        return null;
//    }


    @GetMapping("/test")
    public String testServer() {
        return "Server OK ";
    }

}
